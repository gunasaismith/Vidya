package com.example.doc2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailedInformationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_information);

        // Retrieve the Requirement object from the intent
        Requirement requirement = (Requirement) getIntent().getSerializableExtra("requirement");

        // Display detailed information in the UI
        TextView schoolNameTextView = findViewById(R.id.schoolNameTextView);
        TextView addressTextView = findViewById(R.id.addressTextView);
        TextView phoneNumberTextView = findViewById(R.id.phoneNumberTextView);
        TextView locationLinkTextView = findViewById(R.id.locationLinkTextView);
        TextView topicTextView = findViewById(R.id.topicTextView);

        if (requirement != null) {
            schoolNameTextView.setText("School Name: " + requirement.getSchoolName());
            addressTextView.setText("Address: " + requirement.getAddress());
            phoneNumberTextView.setText("Phone Number: " + requirement.getPhoneNumber());
            locationLinkTextView.setText("Location Link: " + requirement.getLocationLink());
            topicTextView.setText("Topic: " + requirement.getTopic());
        }
    }
}
